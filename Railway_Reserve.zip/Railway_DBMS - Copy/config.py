# config.py

MYSQL_HOST = "localhost"
MYSQL_USER = "root"              # Your MySQL username
MYSQL_PASSWORD = "Mohanacsd@08" # Your MySQL password
MYSQL_DB = "Railway_DBMS"
MYSQL_CURSORCLASS = "DictCursor"
