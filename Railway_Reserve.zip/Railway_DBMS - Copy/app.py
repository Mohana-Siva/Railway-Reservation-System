from flask import Flask, render_template, request, redirect, url_for, session
import MySQLdb
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, render_template, request, redirect, url_for, session, flash
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from flask import send_file
import io
from flask import request, flash
from datetime import datetime, date
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import qrcode
from reportlab.lib.utils import ImageReader

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this for security

# Database Connection
db = MySQLdb.connect(
    host="localhost",
    user="root",  # Change to your MySQL username
    passwd="Mohanacsd@08",  # Change to your MySQL password
    db="Railway_DBMS"
)

# ------------------ Routes ------------------

# Home Page (Check if user is logged in)
@app.route("/")
def landing():
    return render_template("landing.html")



# ---------- Login Route ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']

        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        cursor.close()

        if user:
            # Check if the password is correct
            if check_password_hash(user[2], password):  # user[2] is the password hash
                session['user_id'] = user[0]
                session['username'] = user[1]
                session['email'] = user[3]  # If you store the email in the session
                session['phone'] = user[4]  # If you store the phone in the session
                return redirect(url_for('index'))
            else:
                flash("Invalid password.", "danger")
                return redirect(url_for('login'))
        else:
            flash("Username not found.", "danger")
            return redirect(url_for('login'))

    return render_template("login.html")


# ---------- Register Route ----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        email = request.form.get('email', '')
        phone = request.form.get('phone', '')

        if not username or not password:
            flash("Please fill in both username and password.", "danger")
            return redirect(url_for('register'))
        
        # Check if username already exists
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            flash("Username already exists. Please choose a different one.", "danger")
            return redirect(url_for('register'))

        hashed_password = generate_password_hash(password)

        try:
            cursor.execute("INSERT INTO users (username, password, email, phone) VALUES (%s, %s, %s, %s)", 
                           (username, hashed_password, email, phone))
            db.commit()
            cursor.close()
            return redirect(url_for('login'))
        except MySQLdb.IntegrityError:
            flash("Error registering user.", "danger")
            return redirect(url_for('register'))

    return render_template("register.html")


# ------------------ About Page ------------------
@app.route("/about")
def about():
    return render_template("about.html")

# ------------------ Index Page (After Login) ------------------
@app.route("/index")
def index():
    if 'user_id' not in session:
        return redirect(url_for("login"))
    return render_template("index.html")


# ------------------ Search Trains ------------------
@app.route("/search", methods=["GET", "POST"])
def search():
    if 'user_id' not in session:
        return redirect(url_for("login"))

    # Fetch all trains to display on search page
    cursor = db.cursor()
    cursor.execute("SELECT * FROM trains")
    all_trains = cursor.fetchall()
    cursor.close()

    return render_template("search.html", trains=all_trains)
#------------results-----------------
@app.route("/results", methods=["POST"])
def results():
    if 'user_id' not in session:
        return redirect(url_for("login"))
    
    source = request.form['source']
    destination = request.form['destination']

    cursor = db.cursor()
    cursor.execute("SELECT * FROM trains WHERE source = %s AND destination = %s", 
                   (source, destination))
    filtered_trains = cursor.fetchall()
    cursor.close()

    return render_template("results.html", trains=filtered_trains)

# ------------------ db test ------------------
@app.route("/test_db")
def test_db():
    try:
        cursor = db.cursor()
        cursor.execute("SELECT 1")  # Simple test query
        result = cursor.fetchone()
        cursor.close()
        return f"✅ Database Connected! Test Query Result: {result}"
    except Exception as e:
        return f"❌ Database Connection Failed: {e}"


# ------------------ Logout ------------------
@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("landing"))


# ---------- Profile Page Route ----------
@app.route("/profile", methods=["GET", "POST"])
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = db.cursor()
    if request.method == "POST":
        phone = request.form['phone']
        cursor.execute("UPDATE users SET phone = %s WHERE user_id = %s", (phone, session['user_id']))
        db.commit()

    cursor.execute("SELECT username, email, phone FROM users WHERE user_id = %s", (session['user_id'],))
    user_data = cursor.fetchone()
    cursor.close()

    return render_template("profile.html", user=user_data)
#-------------------booking-------------------
@app.route('/book/<int:train_id>', methods=['GET', 'POST'])
def book(train_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cur = db.cursor()
    cur.execute("SELECT * FROM trains WHERE train_id = %s", (train_id,))
    train = cur.fetchone()
    
    if not train:
        flash("Train not found!", "danger")
        return redirect(url_for('search'))

    if request.method == 'POST':
        passenger_id = request.form['passenger_id']
        seats_booked = request.form['seats_booked']
        booking_date_str = request.form['booking_date']

        try:
            booking_date = datetime.strptime(booking_date_str, '%Y-%m-%d').date()
            today = date.today()

            if booking_date < today:
                flash("Booking date must be today or in the future!", "danger")
                return redirect(request.url)  # reload the booking page

            # Continue saving booking
            cur.execute("""
                INSERT INTO bookings (train_id, passenger_id, seats_booked, booking_date)
                VALUES (%s, %s, %s, %s)
            """, (train_id, passenger_id, seats_booked, booking_date))
            db.commit()

            flash("Booking confirmed!", "success")
            return redirect(url_for('search'))

        except ValueError:
            flash("Invalid date format!", "danger")
            return redirect(request.url)

    current_date = date.today().isoformat()
    return render_template('booking.html', train=train, current_date=current_date)


@app.route('/confirm_booking', methods=['POST'])
def confirm_booking():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    train_id = request.form.get('train_id')
    passenger_name = request.form.get('passenger_name')
    age = request.form.get('age')
    gender = request.form.get('gender')
    phone_number = request.form.get('phone_number')
    seats_booked = request.form.get('seats_booked')
    booking_date = request.form['booking_date']

    if not all([train_id, passenger_name, age, gender, phone_number, seats_booked]):
        flash("All fields are required!", "danger")
        return redirect(url_for('book', train_id=train_id))

    cursor = db.cursor()

    # Insert into passengers table
    cursor.execute("""
        INSERT INTO passengers (name, age, phone_number)
        VALUES (%s, %s, %s)
    """, (passenger_name, age, phone_number))
    passenger_id = cursor.lastrowid

    # Insert into bookings table
    cursor.execute("""
        INSERT INTO bookings (train_id, seats_booked, passenger_id,booking_date)
        VALUES (%s, %s, %s,%s)
    """, (train_id, seats_booked, passenger_id,booking_date))
    db.commit()
    booking_id = cursor.lastrowid
    cursor.close()

    
    return render_template('booking_success.html', booking_id=booking_id)

#----------------pdf-----------------
@app.route('/download_receipt/<int:booking_id>')
def download_receipt(booking_id):
    cur = db.cursor()
    cur.execute("""
        SELECT p.name, b.train_id, b.seats_booked, b.booking_time, b.booking_date, t.train_name, t.source, t.destination
        FROM bookings b
        JOIN passengers p ON b.passenger_id = p.passenger_id
        JOIN trains t ON b.train_id = t.train_id
        WHERE b.booking_id = %s
    """, (booking_id,))
    data = cur.fetchone()

    if not data:
        flash("Booking not found!", "danger")
        return redirect(url_for('search'))

    name, train_id, seats_booked, booking_time, booking_date, train_name, source, destination = data

    # Generate QR code with basic info
    qr_data = f"Booking ID: {booking_id}, Passenger: {name}, Train: {train_name}, Date: {booking_date}"
    qr_img = qrcode.make(qr_data)
    qr_buffer = io.BytesIO()
    qr_img.save(qr_buffer)
    qr_buffer.seek(0)
    qr_reader = ImageReader(qr_buffer)

    # Generate PDF
    pdf_buffer = io.BytesIO()
    c = canvas.Canvas(pdf_buffer, pagesize=LETTER)
    width, height = LETTER

    # Border
    c.setLineWidth(1)
    c.rect(40, 40, width - 80, height - 80)

    # Logo (optional)
    try:
        logo = ImageReader("static/images/img1.jpg")
        c.drawImage(logo, 50, height - 90, width=60, preserveAspectRatio=True, mask='auto')
    except:
        pass  # If logo is missing, skip it

    # Title
    c.setFont("Helvetica-Bold", 18)
    c.drawCentredString(width / 2, height - 60, "Indian Railway Ticket Receipt")

    c.setFont("Helvetica", 12)
    c.drawCentredString(width / 2, height - 80, "Official Booking Confirmation")
    c.drawCentredString(width / 2, height - 100, f"Booking Time: {booking_time.strftime('%d %B %Y, %I:%M %p')}")

    # Line
    c.line(50, height - 110, width - 50, height - 110)

    # Ticket Info
    y = height - 150
    gap = 20
    c.setFont("Helvetica", 11)

    details = [
        ("Booking ID:", booking_id),
        ("Passenger Name:", name),
        ("Train:", f"{train_name} ({train_id})"),
        ("Route:", f"{source} ➡ {destination}"),
        ("Seats Booked:", seats_booked),
        ("Travel Date:", booking_date.strftime("%d %B %Y")),
        ("Status:", "Confirmed ✅"),
    ]

    for label, value in details:
        c.drawString(70, y, label)
        c.drawString(200, y, str(value))
        y -= gap

    # QR Code
    c.drawImage(qr_reader, width - 150, 100, width=100, height=100)

    # Footer
    c.setFont("Helvetica-Oblique", 10)
    c.drawCentredString(width / 2, 60, "Thank you for choosing Indian Railways!")
    c.drawCentredString(width / 2, 45, "For queries, contact support@railwaybooking.com")

    c.save()
    pdf_buffer.seek(0)

    return send_file(
        pdf_buffer,
        as_attachment=True,
        download_name=f"booking_{booking_id}.pdf",
        mimetype='application/pdf'
    )



if __name__ == "__main__":
    app.run(debug=True)
